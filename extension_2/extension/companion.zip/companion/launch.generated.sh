#!/bin/sh
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec '/usr/local/bin/node' "$SCRIPT_DIR/src/companion.mjs" 2>>"$SCRIPT_DIR/companion.log"
