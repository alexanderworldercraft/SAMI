#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main(void) {
  int log_fd = open("/Users/patricktarroz/Documents/pro/dev/sami/extension_2/extension/companion/companion.log", O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (log_fd >= 0) {
    dup2(log_fd, STDERR_FILENO);
    close(log_fd);
  }
  char *const args[] = { "/usr/local/bin/node", "/Users/patricktarroz/Documents/pro/dev/sami/extension_2/extension/companion/src/companion.mjs", NULL };
  execv("/usr/local/bin/node", args);
  perror("Impossible de lancer Node.js");
  return errno ? errno : 127;
}
